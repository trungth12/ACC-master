GroundworkCSS
=============

Say hello to responsive design made easy.

http://groundworkcss.github.com

GroundworkCSS is a fully responsive HTML5, CSS and Javascript toolkit.
Using GroundworkCSS, you can quickly build web apps that work on virtually
any device.
